
let database = firebase.database();
let currentRoom = "";
let playerNames = {};
let currentTurn = "Player 1";
let moveTime = 30;
let timer = null;
let timeLeft = 0;
let gameOver = false;

const pieces = {
  0: "Rook", 1: "Knight", 2: "Bishop", 3: "Queen",
  4: "King", 5: "Bishop", 6: "Knight", 7: "Rook"
};

function startGame() {
  currentRoom = document.getElementById('roomId').value.trim();
  playerNames = {
    "Player 1": document.getElementById('player1').value.trim(),
    "Player 2": document.getElementById('player2').value.trim()
  };
  moveTime = parseInt(document.getElementById('moveTime').value, 10);
  document.querySelector('.setup-screen').style.display = 'none';
  document.querySelector('.game-screen').style.display = 'block';
  document.getElementById('roomName').innerText = currentRoom;

  const boardRef = database.ref(`games/${currentRoom}/board`);
  boardRef.once('value').then(snapshot => {
    let board = snapshot.val();
    if (!board) {
      board = Array.from({ length: 8 }, (_, row) => Array(8).fill(''));
      board[0] = Object.values(pieces);
      board[1] = Array(8).fill('Pawn');
      board[6] = Array(8).fill('Pawn');
      board[7] = Object.values(pieces);
      database.ref(`games/${currentRoom}`).set({ board, turn: "Player 1", winner: "", timeLeft: moveTime });
    }
  });

  database.ref(`games/${currentRoom}`).on('value', snapshot => {
    const data = snapshot.val();
    if (data) {
      createBoard(data.board);
      currentTurn = data.turn;
      timeLeft = data.timeLeft;
      document.getElementById('currentTurn').innerText = playerNames[currentTurn] + " (" + currentTurn + ")";
      document.getElementById('timeLeft').innerText = timeLeft;
      if (data.winner) {
        document.getElementById('winner').innerText = "Winner: " + playerNames[data.winner] + " (" + data.winner + ")";
        gameOver = true;
        clearInterval(timer);
      }
    }
  });

  startTimer();
}

function createBoard(boardState) {
  const board = document.getElementById('board');
  board.innerHTML = '';

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const square = document.createElement('div');
      square.classList.add('square');
      if ((row + col) % 2 === 0) square.classList.add('white');
      else square.classList.add('black');

      square.dataset.row = row;
      square.dataset.col = col;

      const pieceName = boardState[row][col];
      if (pieceName) {
        const piece = document.createElement('div');
        piece.classList.add('piece');
        piece.innerText = pieceName;
        square.appendChild(piece);
      }

      square.addEventListener('click', () => handleSquareClick(row, col));
      board.appendChild(square);
    }
  }
}

let selected = null;

function handleSquareClick(row, col) {
  if (gameOver || currentTurn !== getMyPlayer()) return;
  if (selected) {
    movePiece(selected, { row, col });
    selected = null;
  } else {
    selected = { row, col };
  }
}

function movePiece(from, to) {
  const boardRef = database.ref(`games/${currentRoom}/board`);
  boardRef.once('value').then(snapshot => {
    const board = snapshot.val();
    const piece = board[from.row][from.col];

    if (piece && isValidMove(piece, from, to, board)) {
      board[to.row][to.col] = piece;
      board[from.row][from.col] = '';
      const nextTurn = currentTurn === "Player 1" ? "Player 2" : "Player 1";

      database.ref(`games/${currentRoom}`).update({
        board,
        turn: nextTurn,
        timeLeft: moveTime
      });
    }
  });
}

function isValidMove(piece, from, to, board) {
  // Very basic rule: only allow moving to empty squares for now (you can improve later)
  return !(from.row === to.row && from.col === to.col) && !board[to.row][to.col];
}

function startTimer() {
  clearInterval(timer);
  timer = setInterval(() => {
    if (gameOver) return;

    timeLeft--;
    database.ref(`games/${currentRoom}/timeLeft`).set(timeLeft);
    if (timeLeft <= 0) {
      clearInterval(timer);
      setTimeout(() => {
        const loser = currentTurn;
        alert(playerNames[loser] + " (" + loser + ") lost due to timeout!");

        if (confirm(playerNames[loser] + ", do you want to request a game continue?")) {
          database.ref(`games/${currentRoom}/timeLeft`).set(moveTime);
          startTimer();
        } else {
          database.ref(`games/${currentRoom}/winner`).set(currentTurn === "Player 1" ? "Player 2" : "Player 1");
        }
      }, 200);
    }
  }, 1000);
}

function getMyPlayer() {
  // Auto detect or allow manual player assignment later
  return currentTurn;
}
